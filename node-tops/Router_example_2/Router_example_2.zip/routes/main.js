const express = require("express");

const router = express.Router();
const path = require("path");
const hbs = require("hbs");

hbs.registerHelper("checkAge", (age, option) => {
  if (age > 18) {
    return option.fn(this);
    // like return true
  } else {
    return option.inverse(this);
    // like return false
  }
});

hbs.registerHelper("upperCase", (name, option) => {
  return name.toUpperCase();
});

const data = {
  name: "dev",
  subject: "nodejs",
};

const subject = {
  languages: ["C", "C++", "Ruby", "Python", "Java"],
};

// router.get("/home", (req, res) => {
//   res.render("index");
// });

router.get("/home", (req, res) => {
  res.render("dashboard");
});

router.post("/addEmployee", (req, res) => {
  console.log("Btn clicked");
  console.log(req.body);
  console.log(req.body.name);
  res.redirect("home");
});

router.get("/age", (req, res) => {
  res.render("index", { age: req.query.age });
});

router.get("/about", (req, res) => {
  res.render("about", { data: subject });
});

router.get("/demo", (req, res) => {
  res.render("demo");
});

// router.get("/", (req, res) => {
//   // res.sendFile(path.join(__dirname, "../views/index.html"));
//   res.render("index", { key: data });
// });

// router.get("/about", (req, res) => {
//   res.sendFile(path.join(__dirname, "../views/about.html"));
// });

// router.get("*", (req, res) => {
//   res.sendFile(path.join(__dirname, "../views/404.html"));
// });

module.exports = router;
